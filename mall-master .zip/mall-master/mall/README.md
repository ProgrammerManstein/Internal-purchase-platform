# 商城页面使用

#### 1. 下载依赖包

```
npm i
```

#### 2. 运行项目

```
npm run serve
```

#### 3. 项目打包

```
npm run build
```

