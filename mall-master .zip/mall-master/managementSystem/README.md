# 后台管理项目

## vue+elementUI商城后台管理项目

## 安装工程依赖
```
npm install
```

### 启动工程项目
```
npm run serve
```

### 打包项目
```
npm run build
```
