# 前后端分离内购平台商城项目

### 项目介绍

本项目前端使用vue框架,后端使用flask框架,数据库使用mysql。本页面展示部分主要功能,其余具体功能和代码使用可在对应文件夹文档中查看。

### 项目部分功能

#### 1.前端商城

轮播图

![image-20211224140224662](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140224662.png)

商品图

![image-20211224140312396](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140312396.png)

全部商品图

![image-20211224140332512](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140332512.png)

商品详情

![image-20211224140408073](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140408073.png)

我的收藏

![image-20211224140445314](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140445314.png)

我的购物车

![image-20211224140455233](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140455233.png)

我的订单

![image-20211224140507040](https://gitee.com/gaohuan111/pic/raw/master/img/image-20211224140507040.png)

#### 2.后台管理系统

首页

![image-20220104151515219](https://gitee.com/gaohuan111/pic/raw/master/img/image-20220104151515219.png)

用户管理(增删改查)

![image-20220104151306323](https://gitee.com/gaohuan111/pic/raw/master/img/image-20220104151306323.png)

商品管理(增删改查)

![image-20220104151450421](https://gitee.com/gaohuan111/pic/raw/master/img/image-20220104151450421.png)

订单管理(增删改查)

![image-20220104151439865](https://gitee.com/gaohuan111/pic/raw/master/img/image-20220104151439865.png)

数据统计

![image-20220104151417952](https://gitee.com/gaohuan111/pic/raw/master/img/image-20220104151417952.png)
