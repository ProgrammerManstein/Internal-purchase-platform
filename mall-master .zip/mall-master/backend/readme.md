# 后端代码使用

1.安装pymysql和flask即可运行app.py

2.数据库.sql文件在mysql文件夹中,创建数据库并且修改app.py中的数据库配置项即可使用。

